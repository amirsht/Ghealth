package enums;

/**
 * 
 * The Enums for Doctor Speciallity.
 * @author G5 lab group
 */
public enum DoctorSpeciallity {

	/** Eyes Doctor. */
	Eyes,
	
	/** Cardio Doctor. */
	Cardio,
	
	/** Orthopedist Doctor. */
	Orthopedist, 
	
	/** Neurologist Doctor. */
	Neurologist,
	
	/** Gynecologist Doctor. */
	Gynecologist
}
