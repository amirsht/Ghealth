/**
*the project's enums
*used for the sake of comfort and order for using the diferent 
*constans in a clear matter by our team.
*/
package enums;