/**
*This package contain's the client side controllers
*with their implementation this made possible to communicate with the server
*by monitoring the user actions if they are legal or not.
*
*/
package client;