/**
*the project models class which represents
*all the objects created to to represent the Ghealth information system
*/
package models;