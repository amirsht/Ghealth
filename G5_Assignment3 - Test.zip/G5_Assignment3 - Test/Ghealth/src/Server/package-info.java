/**
*Server side package - containts the server tasks and the controloers to 
*comunicate with the mySQL DataBase
*/
package Server;