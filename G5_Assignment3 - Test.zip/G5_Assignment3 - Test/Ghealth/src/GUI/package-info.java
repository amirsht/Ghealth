/**
*This package contains the User Interface (GUI)
*all the frames and windows that the user "see" - the "front end"
*implemented here in this package
*/
package GUI;